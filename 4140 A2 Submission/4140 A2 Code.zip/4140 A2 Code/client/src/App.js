import React, {useState, useEffect} from 'react';
import './App.css';
import Axios from 'axios';

function App() {

  const [listParts, setListParts] = useState(false);

  const [submitPoNo, setSubmitPoNo] = useState('');
  const [submitClientId, setSubmitClientId] = useState('');
  const [submitDate, setSubmitDate] = useState('');
  const [submitPoStatus, setSubmitPoStatus] = useState('');

  const [linePoNo, setLinePoNo] = useState('');
  const [lineNo, setLineNo] = useState('');
  const [linePartNo, setLinePartNo] = useState('');
  const [lineQty, setLineQty] = useState(0);
  const [linePrice, setLinePrice] = useState(0);

  const [listPoClientId, setListPoClientId] = useState('');
  const [listLinePoNo, setListLinePoNo] = useState('');

  const [res1, setRes1] = useState("");
  const [res2, setRes2] = useState("");
  const [res3, setRes3] = useState("");

  const submitForm = async (e) => {
    e.preventDefault();
    //if List Parts checkbox is checked: List all the parts without the QoH
    if(listParts){
      await Axios.get("http://localhost:3001/api/listParts")
      .then((response) => {
        setRes1("LIST OF PARTS: " + JSON.stringify(response.data));
      })
    }

    // submit a PO
    Axios.post("http://localhost:3001/api/insertPo", {
      poNo: submitPoNo, 
      clientId: submitClientId, 
      poDate: submitDate, 
      poStatus: submitPoStatus
    })
    .then(() => {
      alert("successfully inserted PO!");
    });

    //submit a Lines
    Axios.post("http://localhost:3001/api/insertLine", {
      poNo: linePoNo, 
      lineNo: lineNo, 
      partNo: linePartNo, 
      qty: lineQty, 
      price: linePrice
    })
    .then(() => {
      alert("successfully inserted Line!");
    });

    //List POs of a Client given clientId
    if(listPoClientId !== ''){
      await Axios.get("http://localhost:3001/api/listPOs", {
        params: {
          clientId: listPoClientId
        }
      })
      .then((response) => {
        setRes2("POs OF GIVEN CLIENT: " + JSON.stringify(response.data));
      })
    }

    //List Lines of PO given poNo
    if(listLinePoNo !== ''){
      await Axios.get("http://localhost:3001/api/listLines", {
        params: {
          poNo: listLinePoNo
        }
      })
      .then((response) => {
        setRes3("LINES OF GIVEN PO: " + JSON.stringify(response.data));
      })
    }
  };

  return (
    <div className="App">
      <h1>CSCI 4140 Assignment2</h1>
      <br /><br /><br /><br />
      <form className="form">
        <label className="formLabel">List Parts for sale</label>
        <input type="checkbox" id="getParts" name="getParts" onChange={(e) => {
          setListParts(e.target.checked);
        }}/>

        <br /><br /><hr />

        <p className="formLabel">Submit a PO:</p>
        <label>PO No: </label>
        <input type="text" id="poNo" name="poNo" onChange={(e) => {
          setSubmitPoNo(e.target.value);
        }}/>
        <br/><br/>
        <label>ClientCompID: </label>
        <input type="text" id="clientCompID" name="clientCompID" onChange={(e) => {
          setSubmitClientId(e.target.value);
        }}/>
        <br/><br/>
        <label>Date: </label>
        <input type="date" id="dateOfPO" name="dateOfPO" onChange={(e) => {
          setSubmitDate(e.target.value);
        }}/>
        <br/><br/>
        <label>Status: </label><br/>
          <input type="radio" id="status1" name="poStatus" value="processing" onChange={(e) => {
          setSubmitPoStatus(e.target.value);
        }}/>
          <label htmlFor="status1">Processing</label><br/>
          <input type="radio" id="status2" name="poStatus" value="in-progress" onChange={(e) => {
          setSubmitPoStatus(e.target.value);
        }}/>
          <label htmlFor="status2">In-Progress</label><br/>
          <input type="radio" id="status3" name="poStatus" value="completed" onChange={(e) => {
          setSubmitPoStatus(e.target.value);
        }}/>
          <label htmlFor="status3">Completed</label>
        <br /><br />
        <p className="formLabel">Submit the Line <span className="formSpan">(Optional)</span></p>
        <label>PO No: </label>
        <input type="text" id="poNo" name="poNo" onChange={(e) => {
          setLinePoNo(e.target.value);
        }}/><br/><br/>
        <label>Line No: </label>
        <input type="text" id="lineNo" name="lineNo" onChange={(e) => {
          setLineNo(e.target.value);
        }}/><br/><br/>
        <label>Part No: </label>
        <input type="text" id="partNo" name="partNo" onChange={(e) => {
          setLinePartNo(e.target.value);
        }}/><br/><br/>
        <label>Quantity: </label>
        <input type="number" id="qty" name="qty" onChange={(e) => {
          setLineQty(e.target.value);
        }}/><br/><br/>
        <label>PriceOrdered - Price of the part: </label>
        <input type="number" id="priceOrdered" name="priceOrdered" onChange={(e) => {
          setLinePrice(e.target.value);
        }}/>

        <br /><br /><hr />

        <p className="formLabel">List POs of Client: <input type="text" id="clientId" name="clientId" placeholder="Client ID" onChange={(e) => {
          setListPoClientId(e.target.value);
        }}/></p>

        <p className="formLabel">List Lines of PO: <input type="text" id="clientId" name="clientId" placeholder="PO No" onChange={(e) => {
          setListLinePoNo(e.target.value);
        }}/> </p>  
        <button onClick={submitForm}>Submit</button>    
      </form>   
      <div>
        <br /><br />
        {res1} <br /><br />
        {res2} <br/><br />
        {res3}
      </div>  
    </div>
  );
}

export default App;
