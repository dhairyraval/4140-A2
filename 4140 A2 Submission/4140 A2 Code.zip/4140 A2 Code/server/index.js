const express = require('express');
const app = express();
const cors = require('cors');
const port = 3001;
const mysql = require('mysql');;
const bodyParser = require('body-parser');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Pass@123',
    database: 'A2'
});

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));

// GET details about parts excluding the QoH
app.get('/api/listParts', (req, res) => {
    const sqlGet = "SELECT partNo519, partName519, currentPrice519 FROM parts519;"
    db.query(sqlGet, (err, result) => {
        res.send(result);
    })
});

// POST a new PO into the db
app.post('/api/insertPo', (req, res) => {
    const poNo = req.body.poNo;
    const clientId = req.body.clientId;
    const poDate = req.body.poDate;
    const poStatus = req.body.poStatus;

    const sqlInsert = "INSERT INTO pos519 (poNo519, clientCompID519, dateOfPO519, status519) VALUES (?,?,?,?)";
    db.query(sqlInsert, [poNo, clientId, poDate, poStatus], (err, result) => {
        console.log(err);
        console.log(result);
    })
});

// POST a new Line into the db
app.post('/api/insertLine', (req, res) => {
    const poNo = req.body.poNo;
    const lineNo = req.body.lineNo;
    const partNo = req.body.partNo;
    const qty = req.body.qty;
    const price = req.body.price;

    const sqlInsert = "INSERT INTO lines519 (poNo519, lineNo519, partNo519, qty519, priceOrdered519) VALUES (?,?,?,?,?)";
    db.query(sqlInsert, [poNo, lineNo, partNo, qty, price], (err, result) => {
        console.log(err);
        console.log(result);
    })
});

// GET list of POs of a given client
app.get('/api/listPOs', (req, res) => {
    const clientId = req.query.clientId;
    const sqlGet = "SELECT * FROM pos519 WHERE clientCompID519 = ?;"
    db.query(sqlGet, [clientId], (err, result) => {
        res.send(result);
    });
});

// GET Lines of given PO
app.get('/api/listLines', (req, res) => {
    const poNo = req.query.poNo;
    const sqlGet = "SELECT * FROM lines519 WHERE poNo519 = ?;"
    db.query(sqlGet, [poNo], (err, result) => {
        res.send(result);
    });
});

app.listen(port, () => {
    console.log('listening on port ' + port);
});
